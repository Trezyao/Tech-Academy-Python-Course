function payWithPaystack() {
    var handler = PaystackPop.setup({
        key: 'pk_test_88f80e7e41e4a2634424410180e5c0bae9cc8fc5',
        email: 'adesuwaozem2006@gmail.com',
        amount: 500000, // 5000 Naira in kobo
        currency: 'NGN',
        callback: function(response){
            window.location.href = "thankyou.html";
        },
        onClose: function(){
            alert('Transaction was not completed.');
        }
    });
    handler.openIframe();
}